define({
  root: {
    _widgetLabel: "CommonBase"
  },
  
  "es": true,
  
  "zh-cn": true
});
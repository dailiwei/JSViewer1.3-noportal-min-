﻿define({

    _widgetLabel: "公共方法"

});